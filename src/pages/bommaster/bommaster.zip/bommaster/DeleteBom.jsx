// DeleteBom.jsx
import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Typography,
  Button,
  Alert,
  Box,
  IconButton
} from '@mui/material';
import {
  Close as CloseIcon,
  Warning as WarningIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';
import axios from 'axios';

const COLORS = {
  primary: '#063C3F',
  text: {
    primary: '#151C26',
    secondary: '#4B5568'
  },
  background: {
    white: '#FFFFFF'
  },
  border: '#E3E8EF'
};

const DeleteBom = ({ open, onClose, bom, onDelete }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const handleDelete = async () => {
    setLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('token');
      const response = await axios.delete(`http://192.168.1.13:5009/api/boms/${bom._id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.data.success) {
        onDelete();
        onClose();
      } else {
        setError(response.data.message || 'Failed to delete BOM');
      }
    } catch (err) {
      console.error('Error deleting BOM:', err);
      setError(err.response?.data?.message || 'Failed to delete BOM. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 2,
          border: `1px solid ${COLORS.border}`,
          overflow: 'hidden'
        }
      }}
    >
      <DialogTitle sx={{
        borderBottom: `1px solid ${COLORS.border}`,
        py: 1.5,
        px: 2.5,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <Typography sx={{ fontSize: '1.1rem', fontWeight: 700, color: '#DC2626' }}>
          Delete BOM
        </Typography>
        <IconButton onClick={onClose} size="small">
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>
      
      <DialogContent sx={{ p: 2.5 }}>
        <Box sx={{ textAlign: 'center', py: 2 }}>
          <WarningIcon sx={{ fontSize: 48, color: '#DC2626', mb: 2 }} />
          <Typography sx={{ fontSize: '1rem', fontWeight: 600, color: COLORS.text.primary, mb: 1 }}>
            Are you sure you want to delete this BOM?
          </Typography>
          <Typography sx={{ fontSize: '0.8rem', color: COLORS.text.secondary }}>
            BOM ID: <strong>{bom?.bom_id}</strong>
          </Typography>
          <Typography sx={{ fontSize: '0.75rem', color: COLORS.text.secondary, mt: 1 }}>
            Parent Part: {bom?.parent_part_no}
          </Typography>
          <Typography sx={{ fontSize: '0.7rem', color: '#DC2626', mt: 2 }}>
            This action cannot be undone.
          </Typography>
        </Box>
        
        {error && (
          <Alert severity="error" sx={{ mt: 2, borderRadius: 1.5, fontSize: '0.75rem' }}>
            {error}
          </Alert>
        )}
      </DialogContent>
      
      <DialogActions sx={{
        px: 2.5,
        py: 1.5,
        borderTop: `1px solid ${COLORS.border}`,
        gap: 1
      }}>
        <Button
          onClick={onClose}
          disabled={loading}
          sx={{
            height: 32,
            px: 2,
            borderRadius: 1.5,
            border: `1px solid ${COLORS.border}`,
            color: COLORS.text.secondary,
            fontSize: '0.7rem',
            textTransform: 'none'
          }}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleDelete}
          disabled={loading}
          startIcon={loading ? null : <DeleteIcon sx={{ fontSize: '1rem' }} />}
          sx={{
            height: 32,
            px: 2,
            borderRadius: 1.5,
            bgcolor: '#DC2626',
            fontSize: '0.7rem',
            fontWeight: 500,
            textTransform: 'none',
            '&:hover': { bgcolor: '#B91C1C' }
          }}
        >
          {loading ? 'Deleting...' : 'Delete'}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteBom;