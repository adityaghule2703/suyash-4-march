import React, { useState, useEffect } from "react";
import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Button,
  TextField,
  InputAdornment,
  Tooltip,
  Typography,
  Snackbar,
  TablePagination,
  Checkbox,
  Stack,
  alpha,
  Alert,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material";

import {
  Search as SearchIcon,
  FilterList as FilterIcon,
  Download as DownloadIcon,
  Add as AddIcon,
  Delete as DeleteIcon,
  ArrowUpward as ArrowUpwardIcon,
  Visibility as ViewIcon,
  Edit as EditIcon,
  MoreVert as MoreVertIcon,
  Sort as SortIcon,
} from "@mui/icons-material";

import axios from "axios";
import BASE_URL from "../../../config/Config";

import AddShifts from "./AddShifts";
import EditShifts from "./EditShifts";
import AssignShift from "./AssignShift";
import ViewShifts from "./ViewShifts";
import DeleteShifts from "./DeleteShifts";

// Color constants - EXACT SAME as header gradient
const HEADER_GRADIENT =
  "linear-gradient(135deg, #164e63 0%, #00B4D8 50%, #0e7490 100%)";
const STRIPE_COLOR_ODD = "#FFFFFF";
const STRIPE_COLOR_EVEN = "#f8fafc"; // slate-50
const HOVER_COLOR = "#f1f5f9"; // slate-100
const PRIMARY_BLUE = "#00B4D8";
const TEXT_COLOR_HEADER = "#FFFFFF";
const TEXT_COLOR_MAIN = "#0f172a"; // slate-900

// Action Menu Component
const ActionMenu = ({ shift, onView, onEdit, onDelete, anchorEl, onClose, onOpen }) => {
  return (
    <>
      <Tooltip title="Actions">
        <IconButton
          size="small"
          onClick={onOpen}
          sx={{
            color: "#64748b", // slate-500
            "&:hover": {
              bgcolor: alpha(PRIMARY_BLUE, 0.1),
            },
          }}
        >
          <MoreVertIcon fontSize="small" />
        </IconButton>
      </Tooltip>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={onClose}
        PaperProps={{
          elevation: 3,
          sx: {
            mt: 1,
            minWidth: 180,
            borderRadius: 2,
            border: "1px solid #e2e8f0",
          },
        }}
      >
        <MenuItem
          onClick={() => {
            onView(shift);
            onClose();
          }}
          sx={{ py: 1 }}
        >
          <ListItemIcon sx={{ color: PRIMARY_BLUE, minWidth: 36 }}>
            <ViewIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            <Typography variant="body2" fontWeight={500}>
              View Details
            </Typography>
          </ListItemText>
        </MenuItem>
        <MenuItem
          onClick={() => {
            onEdit(shift);
            onClose();
          }}
          sx={{ py: 1 }}
        >
          <ListItemIcon sx={{ color: "#10B981", minWidth: 36 }}>
            <EditIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            <Typography variant="body2" fontWeight={500}>
              Edit
            </Typography>
          </ListItemText>
        </MenuItem>
        <Divider sx={{ my: 0.5 }} />
        <MenuItem
          onClick={() => {
            onDelete(shift);
            onClose();
          }}
          sx={{ py: 1 }}
        >
          <ListItemIcon sx={{ color: "#EF4444", minWidth: 36 }}>
            <DeleteIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>
            <Typography variant="body2" fontWeight={500} color="#EF4444">
              Delete
            </Typography>
          </ListItemText>
        </MenuItem>
      </Menu>
    </>
  );
};

const ShiftMaster = () => {
  const [shifts, setShifts] = useState([]);
  const [filteredShifts, setFilteredShifts] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [selectedShift, setSelectedShift] = useState(null);
  const [actionMenuAnchor, setActionMenuAnchor] = useState(null);
  const [selectedShiftForAction, setSelectedShiftForAction] = useState(null);

  const [openAddModal, setOpenAddModal] = useState(false);
  const [openEditModal, setOpenEditModal] = useState(false);
  const [openAssignModal, setOpenAssignModal] = useState(false);
  const [openViewModal, setOpenViewModal] = useState(false);
  const [openDeleteModal, setOpenDeleteModal] = useState(false);

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  useEffect(() => {
    fetchShifts();
  }, []);

  const fetchShifts = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const res = await axios.get(`${BASE_URL}/api/shifts`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.data.success) {
        setShifts(res.data.data || []);
        setFilteredShifts(res.data.data || []);
      }
    } catch {
      showNotification("Failed to load shifts", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchTerm(value);

    const filtered = shifts.filter(
      (shift) =>
        shift?.ShiftName?.toLowerCase().includes(value) ||
        shift?.Code?.toLowerCase().includes(value)
    );

    setFilteredShifts(filtered);
    setPage(0);
  };

  const handleSelectAll = (event) => {
    if (event.target.checked) {
      setSelected(filteredShifts.map((s) => s._id));
    } else {
      setSelected([]);
    }
  };

  const handleSelectOne = (id) => {
    if (selected.includes(id)) {
      setSelected(selected.filter((item) => item !== id));
    } else {
      setSelected([...selected, id]);
    }
  };

  const handleBulkDelete = () => {
    setSelectedShift({ _id: selected });
    setOpenDeleteModal(true);
  };

  // Action menu handlers
  const handleActionMenuOpen = (event, shift) => {
    setActionMenuAnchor(event.currentTarget);
    setSelectedShiftForAction(shift);
  };

  const handleActionMenuClose = () => {
    setActionMenuAnchor(null);
    setSelectedShiftForAction(null);
  };

  const handleView = (shift) => {
    setSelectedShift(shift);
    setOpenViewModal(true);
  };

  const handleEdit = (shift) => {
    setSelectedShift(shift);
    setOpenEditModal(true);
  };

  const handleDelete = (shift) => {
    setSelectedShift(shift);
    setOpenDeleteModal(true);
  };

  const showNotification = (message, severity) => {
    setSnackbar({ open: true, message, severity });
  };

  const paginatedShifts = filteredShifts.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Format time to display nicely
  const formatTime = (timeString) => {
    if (!timeString) return "—";
    return timeString;
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Typography
          variant="h5"
          component="h1"
          fontWeight="600"
          sx={{
            color: TEXT_COLOR_MAIN,
            background: HEADER_GRADIENT,
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            display: "inline-block",
          }}
        >
          Shift Master
        </Typography>
        <Typography variant="body2" color="#64748B" sx={{ mt: 0.5 }}>
          Manage and organize company shifts and scheduling details
        </Typography>
      </Box>

      {/* Action Bar */}
      <Paper
        sx={{
          p: 2,
          mb: 3,
          borderRadius: 2,
          bgcolor: "#FFFFFF",
          boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.05)",
          border: "1px solid #e2e8f0",
        }}
      >
        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={2}
          alignItems="center"
          justifyContent="space-between"
        >
          {/* Search and Filters */}
          <Stack direction="row" spacing={2} alignItems="center" sx={{ flex: 1 }}>
            <TextField
              placeholder="Search by shift name or code..."
              size="small"
              value={searchTerm}
              onChange={handleSearch}
              sx={{
                width: { xs: "100%", sm: 320 },
                "& .MuiOutlinedInput-root": {
                  borderRadius: 1.5,
                  "&:hover fieldset": {
                    borderColor: PRIMARY_BLUE,
                  },
                },
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon sx={{ color: "#64748B" }} />
                  </InputAdornment>
                ),
                sx: {
                  height: 40,
                  bgcolor: "#f8fafc",
                  "& input": {
                    padding: "8px 12px",
                    fontSize: "0.875rem",
                  },
                },
              }}
              disabled={loading}
            />
            {/* <Button
              variant="outlined"
              startIcon={<FilterIcon />}
              sx={{
                height: 40,
                borderRadius: 1.5,
                borderColor: "#cbd5e1",
                color: "#475569",
                fontSize: "0.875rem",
                fontWeight: 500,
                textTransform: "none",
                "&:hover": {
                  borderColor: PRIMARY_BLUE,
                  bgcolor: alpha(PRIMARY_BLUE, 0.04),
                },
              }}
              disabled={loading}
            >
              Filter
            </Button>
            <Button
              variant="outlined"
              startIcon={<SortIcon />}
              sx={{
                height: 40,
                borderRadius: 1.5,
                borderColor: "#cbd5e1",
                color: "#475569",
                fontSize: "0.875rem",
                fontWeight: 500,
                textTransform: "none",
                "&:hover": {
                  borderColor: PRIMARY_BLUE,
                  bgcolor: alpha(PRIMARY_BLUE, 0.04),
                },
              }}
              disabled={loading}
            >
              Sort
            </Button> */}
          </Stack>

          {/* Action Buttons */}
          <Stack direction="row" spacing={2} alignItems="center">
            {selected.length > 0 && (
              <Button
                variant="outlined"
                color="error"
                startIcon={<DeleteIcon />}
                onClick={handleBulkDelete}
                sx={{
                  height: 40,
                  borderRadius: 1.5,
                  textTransform: "none",
                  fontSize: "0.875rem",
                  fontWeight: 500,
                }}
                disabled={loading}
              >
                Delete ({selected.length})
              </Button>
            )}
            {/* <Button
              variant="outlined"
              startIcon={<DownloadIcon />}
              sx={{
                height: 40,
                borderRadius: 1.5,
                borderColor: "#cbd5e1",
                color: "#475569",
                fontSize: "0.875rem",
                fontWeight: 500,
                textTransform: "none",
                "&:hover": {
                  borderColor: PRIMARY_BLUE,
                  bgcolor: alpha(PRIMARY_BLUE, 0.04),
                },
              }}
              disabled={loading}
            >
              Export
            </Button> */}
            <Button
              variant="outlined"
              onClick={() => setOpenAssignModal(true)}
              sx={{
                height: 40,
                borderRadius: 1.5,
                borderColor: "#cbd5e1",
                color: "#475569",
                fontSize: "0.875rem",
                fontWeight: 500,
                textTransform: "none",
                "&:hover": {
                  borderColor: PRIMARY_BLUE,
                  bgcolor: alpha(PRIMARY_BLUE, 0.04),
                },
              }}
              disabled={loading}
            >
              Assign Shift
            </Button>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={() => setOpenAddModal(true)}
              sx={{
                height: 40,
                borderRadius: 1.5,
                background: HEADER_GRADIENT,
                fontSize: "0.875rem",
                fontWeight: 500,
                textTransform: "none",
                "&:hover": {
                  opacity: 0.9,
                  background: HEADER_GRADIENT,
                },
              }}
              disabled={loading}
            >
              Add Shift
            </Button>
          </Stack>
        </Stack>
      </Paper>

      {/* Shifts Table */}
      <Paper
        sx={{
          width: "100%",
          borderRadius: 2,
          overflow: "hidden",
          boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.05)",
          border: "1px solid #e2e8f0",
        }}
      >
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow
                sx={{
                  background: HEADER_GRADIENT,
                  "& .MuiTableCell-root": {
                    borderBottom: "none",
                    color: TEXT_COLOR_HEADER,
                  },
                }}
              >
                <TableCell padding="checkbox" sx={{ width: 60 }}>
                  <Checkbox
                    indeterminate={selected.length > 0 && selected.length < filteredShifts.length}
                    checked={filteredShifts.length > 0 && selected.length === filteredShifts.length}
                    onChange={handleSelectAll}
                    sx={{
                      color: TEXT_COLOR_HEADER,
                      "&.Mui-checked": {
                        color: TEXT_COLOR_HEADER,
                      },
                      "&.MuiCheckbox-indeterminate": {
                        color: TEXT_COLOR_HEADER,
                      },
                      "& .MuiSvgIcon-root": {
                        fontSize: 20,
                      },
                    }}
                    disabled={loading}
                  />
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    color: TEXT_COLOR_HEADER,
                  }}
                >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    Shift Name
                    <ArrowUpwardIcon
                      sx={{ fontSize: 14, color: TEXT_COLOR_HEADER, opacity: 0.9 }}
                    />
                  </Stack>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    color: TEXT_COLOR_HEADER,
                  }}
                >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    Code
                    <ArrowUpwardIcon
                      sx={{ fontSize: 14, color: TEXT_COLOR_HEADER, opacity: 0.9 }}
                    />
                  </Stack>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    color: TEXT_COLOR_HEADER,
                  }}
                >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    Start Time
                    <ArrowUpwardIcon
                      sx={{ fontSize: 14, color: TEXT_COLOR_HEADER, opacity: 0.9 }}
                    />
                  </Stack>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    color: TEXT_COLOR_HEADER,
                  }}
                >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    End Time
                    <ArrowUpwardIcon
                      sx={{ fontSize: 14, color: TEXT_COLOR_HEADER, opacity: 0.9 }}
                    />
                  </Stack>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    color: TEXT_COLOR_HEADER,
                  }}
                >
                  <Stack direction="row" alignItems="center" spacing={0.5}>
                    Grace Period
                    <ArrowUpwardIcon
                      sx={{ fontSize: 14, color: TEXT_COLOR_HEADER, opacity: 0.9 }}
                    />
                  </Stack>
                </TableCell>
                <TableCell
                  sx={{
                    fontWeight: 700,
                    fontSize: "0.875rem",
                    py: 2,
                    width: 100,
                    color: TEXT_COLOR_HEADER,
                  }}
                  align="center"
                >
                  Actions
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 8 }}>
                    <Typography color="textSecondary" sx={{ fontStyle: "italic" }}>
                      Loading shifts...
                    </Typography>
                  </TableCell>
                </TableRow>
              ) : paginatedShifts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 8 }}>
                    <Box sx={{ textAlign: "center" }}>
                      <Typography variant="body1" color="#64748B" fontWeight={500}>
                        {searchTerm ? "No shifts found" : "No shifts available"}
                      </Typography>
                      <Typography variant="body2" color="#94A3B8" sx={{ mt: 1 }}>
                        {searchTerm
                          ? "Try adjusting your search terms"
                          : "Add your first shift to get started"}
                      </Typography>
                    </Box>
                  </TableCell>
                </TableRow>
              ) : (
                paginatedShifts.map((shift, index) => {
                  const isSelected = selected.includes(shift._id);
                  const isOddRow = index % 2 === 0;
                  const isActionMenuOpen =
                    Boolean(actionMenuAnchor) && selectedShiftForAction?._id === shift._id;

                  return (
                    <TableRow
                      key={shift._id}
                      hover
                      selected={isSelected}
                      sx={{
                        bgcolor: isOddRow ? STRIPE_COLOR_ODD : STRIPE_COLOR_EVEN,
                        "&:hover": {
                          bgcolor: HOVER_COLOR,
                        },
                        "&.Mui-selected": {
                          bgcolor: alpha(PRIMARY_BLUE, 0.08),
                          "&:hover": {
                            bgcolor: alpha(PRIMARY_BLUE, 0.12),
                          },
                        },
                      }}
                    >
                      <TableCell padding="checkbox" sx={{ width: 60 }}>
                        <Checkbox
                          checked={isSelected}
                          onChange={() => handleSelectOne(shift._id)}
                          sx={{
                            color: PRIMARY_BLUE,
                            "&.Mui-checked": {
                              color: PRIMARY_BLUE,
                            },
                          }}
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" fontWeight={600} color={TEXT_COLOR_MAIN}>
                          {shift.ShiftName}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="#475569">
                          {shift.Code || "—"}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="#475569">
                          {formatTime(shift.StartTime)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="#475569">
                          {formatTime(shift.EndTime)}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" color="#475569">
                          {shift.GracePeriod ? `${shift.GracePeriod} min` : "—"}
                        </Typography>
                      </TableCell>
                      <TableCell align="center" sx={{ width: 100 }}>
                        <ActionMenu
                          shift={shift}
                          onView={handleView}
                          onEdit={handleEdit}
                          onDelete={handleDelete}
                          anchorEl={isActionMenuOpen ? actionMenuAnchor : null}
                          onClose={handleActionMenuClose}
                          onOpen={(e) => handleActionMenuOpen(e, shift)}
                        />
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Pagination */}
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={filteredShifts.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={(e, newPage) => setPage(newPage)}
          onRowsPerPageChange={(e) => {
            setRowsPerPage(parseInt(e.target.value, 10));
            setPage(0);
          }}
          sx={{
            borderTop: "1px solid #e2e8f0",
            "& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows": {
              fontSize: "0.875rem",
              color: "#64748B",
            },
            "& .MuiTablePagination-actions button": {
              color: PRIMARY_BLUE,
            },
          }}
        />
      </Paper>

      {/* Delete Modal */}
      <DeleteShifts
        open={openDeleteModal}
        onClose={() => {
          setOpenDeleteModal(false);
          setSelectedShift(null);
          setSelected([]);
        }}
        shift={selectedShift}
        onDelete={() => {
          fetchShifts();
          setSelected([]);
          showNotification("Shift deleted successfully", "success");
        }}
      />

      {/* Add Modal */}
      <AddShifts
        open={openAddModal}
        onClose={() => setOpenAddModal(false)}
        onAdd={fetchShifts}
      />

      {/* Edit Modal */}
      {selectedShift && (
        <EditShifts
          open={openEditModal}
          onClose={() => {
            setOpenEditModal(false);
            setSelectedShift(null);
          }}
          shift={selectedShift}
          onUpdate={fetchShifts}
        />
      )}

      {/* Assign Shift Modal */}
      <AssignShift
        open={openAssignModal}
        onClose={() => setOpenAssignModal(false)}
      />

      {/* View Modal */}
      {selectedShift && (
        <ViewShifts
          open={openViewModal}
          onClose={() => {
            setOpenViewModal(false);
            setSelectedShift(null);
          }}
          shift={selectedShift}
        />
      )}

      {/* Snackbar Notification */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={3000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          variant="filled"
          sx={{
            width: "100%",
            borderRadius: 1.5,
            boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ShiftMaster;